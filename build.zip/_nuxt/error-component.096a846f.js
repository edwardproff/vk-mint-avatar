import{u as r}from"./entry.777417af.js";const t={__name:"error",setup(o){return r().push({path:"/"}),()=>{}}},u=t;export{u as default};
