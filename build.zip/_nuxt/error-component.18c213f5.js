import{u as r}from"./entry.8fbd05c8.js";const t={__name:"error",setup(o){return r().push({path:"/"}),()=>{}}},u=t;export{u as default};
