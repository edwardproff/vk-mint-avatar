import{u as r}from"./entry.a4ea6699.js";const t={__name:"error",setup(o){return r().push({path:"/"}),()=>{}}},u=t;export{u as default};
