import{u as r}from"./entry.e2e5fa48.js";const t={__name:"error",setup(o){return r().push({path:"/"}),()=>{}}},u=t;export{u as default};
